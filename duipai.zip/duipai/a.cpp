/***************************************************************
	File name: tree.cpp
	Author: huhao
	Create time: Wed 16 Jun 2021 10:11:55 AM CST
***************************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<assert.h>
#define i64 long long
#define fr(i,a,b) for(int i=(a),end_##i=(b);i<=end_##i;i++)
#define fd(i,a,b) for(int i=(a),end_##i=(b);i>=end_##i;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=r*10+c-48;
		c=getchar();
	}
	return r*t;
}
#include<array>
#define info std::array<i64,3>
const int N=1<<19|10,ninf=-2147483648;
int n,q,m; int lst;
int mi[N],mx[N],t[N]; info v[N];
info operator+(info a,info b){ return {a[0]+b[0],a[1]+b[1],a[2]+b[2]+a[1]*b[0]}; }
void update(int k)
{
	mi[k]=std::min(mi[k<<1],mi[k<<1|1]); mx[k]=std::max(mx[k<<1],mx[k<<1|1]);
	v[k]=v[k<<1]+v[k<<1|1];
}
void Tag(int k,int w)
{
	t[k]=w; v[k][1]=v[k][0]*w; mi[k]=mx[k]=w; v[k][2]=(i64)v[k][0]*(v[k][0]+1)/2*w;
}
void pushdown(int k)
{
	if(t[k]!=ninf){ Tag(k<<1,t[k]); Tag(k<<1|1,t[k]); t[k]=ninf; }
}
void build(int k,int l,int r)
{
	t[k]=ninf;
	if(l==r)
	{
		int R=read(),w=R-lst; lst=R;
		v[k][0]=1; Tag(k,w); return ;
	}
	int mid=(l+r)>>1; build(k<<1,l,mid); build(k<<1|1,mid+1,r); update(k);
}
void modify(int k,int l,int r,int L,int R,int v)
{
	if(L>r||l>R) return ;
	if(L<=l&&r<=R){ Tag(k,v); return ; }
	int mid=(l+r)>>1; pushdown(k);
	modify(k<<1,l,mid,L,R,v); modify(k<<1|1,mid+1,r,L,R,v); update(k);
}
info query1(int k,int l,int r,int L,int R)
{
	if(L<=l&&r<=R) return v[k];
	if(l>R||L>r) return {0,0,0};
	int mid=(l+r)>>1; pushdown(k);
	return query1(k<<1,l,mid,L,R)+query1(k<<1|1,mid+1,r,L,R);
}
int query2(int k,int l,int r,int L,int R)
{
	if((mi[k]>=-m&&mx[k]<=m)||l>R||L>r) return 0;
	if(l==r) return l;
	int mid=(l+r)>>1; pushdown(k);
	int ans=query2(k<<1,l,mid,L,R);
	if(!ans) ans=query2(k<<1|1,mid+1,r,L,R);
	return ans;
}
int query3(int k,int l,int r,int p)
{
	if(r<p) return r;
	if(mi[k]>=m) return r;
	if(l==r) return l-1;
	int mid=(l+r)>>1; pushdown(k);
	int ans=query3(k<<1,l,mid,p);
	if(ans==mid) ans=query3(k<<1|1,mid+1,r,p);
	return ans;
}
int query4(int k,int l,int r,int p)
{
	if(l>p) return l;
	if(mx[k]<=-m) return l;
	if(l==r) return r+1;
	int mid=(l+r)>>1; pushdown(k);
	int ans=query4(k<<1|1,mid+1,r,p);
	if(ans==mid+1) ans=query4(k<<1,l,mid,p);
	return ans;
}
int main()
{
	n=read(); q=read(); m=read();
	build(1,1,n);
/*	fr(i,1,n) printf("%lld%c",query1(1,1,n,1,i)[1],i==n?'\n':' ');
	fr(i,1,n) printf("%lld%c",query1(1,1,n,i,i)[1],i==n?'\n':' ');
	putchar(10);*/
	while(q--)
	{
		int op=read();
		if(op==1)
		{
			int l=read(),r=read();
			i64 s1=query1(1,1,n,1,l-1)[1],s2=query1(1,1,n,l,r)[2];
			printf("%lld\n",s1*(r-l+1)+s2);
		}
		else if(op==2)
		{
			int l=read(),r=read(),c=read();
			modify(1,1,n,l,l,query1(1,1,n,l,l)[1]+c); modify(1,1,n,r+1,r+1,query1(1,1,n,r+1,r+1)[1]-c);
		}
		else if(op==3)
		{
			int p; int L=read()+1,R=read(); //printf(" %d %d\n",L,R);
			while((p=query2(1,1,n,L,R)))
			{
				i64 q=query1(1,1,n,p,p)[1];
				if(q<-m)
				{
					int l=std::max(L,query4(1,1,n,p))-1;
					modify(1,1,n,l,l,query1(1,1,n,l,p)[1]+(i64)(p-l+1-1)*m); modify(1,1,n,l+1,p,-m);
				}
				else
				{
//					assert(q>m);
					int l=std::min(R,query3(1,1,n,p))+1;
					modify(1,1,n,l,l,query1(1,1,n,p,l)[1]-(i64)(l-p+1-1)*m); modify(1,1,n,p,l-1,m);
				}
//				static int cnt=0;
//				if(++cnt%100000==0) fprintf(stderr,"%d\n",cnt);
			}
		}
		else assert(0);
	}
	return 0;
}
