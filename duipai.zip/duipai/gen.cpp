#include"gen.h"
int main()
{
	int n=1000,q=n,w=10000,m=rand(1,w);
	out({n,q,m});
	out(seq(n,1,w));
	while(q--)
		switch(rand()%5)
		{
			case 0:
			case 4:
			{
				int l=rand(1,n),r=rand(1,n); if(l>r) std::swap(l,r);
				out({1,l,r}); break;
			}
			case 1:
			{
				int l=rand(1,n),r=rand(1,n); if(l>r) std::swap(l,r);
				out({2,l,r,rand(-w,w)}); break;
			}
			case 2:
			case 3:
			{
				int l=rand(1,n),r=rand(1,n); if(l>r) std::swap(l,r);
				out({3,l,r}); break;
			}
		}
	return 0;
}
