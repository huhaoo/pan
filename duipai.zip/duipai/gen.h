/***************************************************************
	File name: gen.h
	Author: huhao
	Create time: Tue 30 Mar 2021 04:18:33 PM CST
***************************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<vector>
#include<random>
#include<string>
#include<iostream>
#define i64 long long
#define u64 unsigned long long
#define fr(i,a,b) for(int i=(a),end_##i=(b);i<=end_##i;i++)
#define fd(i,a,b) for(int i=(a),end_##i=(b);i>=end_##i;i--)
struct _Rand
{
	std::mt19937 _rand;
	_Rand()
	{
		FILE *f=fopen("/dev/urandom","r");
		static char s[130]; fread(s,1,128,f); unsigned sed=0;
		fr(i,0,127) sed=sed*sed+sed+s[i];
		_rand=std::mt19937(sed);
	}
	u64 operator()(){ return (u64)_rand()<<32|_rand(); }
} Rand;
i64 rand(i64 l,i64 r){ return (i64)(Rand()%(r-l+1)+l); }
i64 rand_in(std::vector<i64> a){ return a[rand(0,a.size()-1)]; }
void out(i64 a,char c='\n'){ printf("%lld%c",a,c); }
void out(std::vector<i64> a,char c='\n'){ fr(i,0,a.size()-1) out(a[i],i==end_i?c:' '); }
void out(std::vector<std::vector<i64> > a){ for(auto i:a) out(i); }
void outs(std::string a,char c='\n'){ std::cout<<a<<c; }
std::vector<i64> seq(i64 l,i64 r){ std::vector<i64> a; fr(i,l,r) a.push_back(i); return a; }
std::vector<i64> seq(i64 n,i64 l,i64 r){ std::vector<i64> a; fr(i,1,n) a.push_back(rand(l,r)); return a; }
std::vector<i64> shuffle(std::vector<i64> a){ fr(i,1,a.size()-1) std::swap(a[i],a[rand(0,i)]); return a; }
std::string randstr(int n,int l,int r){ std::string a; fr(i,0,n-1) a.push_back(rand(l,r)); return a; }
std::string randstr(int n,std::string S){ std::string a; fr(i,0,n-1) a.push_back(S[rand(0,S.size()-1)]); return a; }
