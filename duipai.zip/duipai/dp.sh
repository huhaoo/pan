g++ a.cpp -o a -O2 -std=c++17 
g++ b.cpp -o b -O2 -std=c++17 
g++ gen.cpp -o gen -O2 -std=c++17 
i=0
while true;
do
	i=$(($i+1))
	./gen>in
	./a<in>out
	./b<in>ans
	if diff out ans -b -B ;
	then
		if [ $(($i%10)) = 0 ] ;
		then
			echo "Accepted $i."
		fi
	else
		echo "Wrong Answer #$i."
		exit
	fi
done
