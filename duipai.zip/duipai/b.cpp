/***************************************************************
	File name: bf.cpp
	Author: huhao
	Create time: Wed 16 Jun 2021 11:33:23 AM CST
***************************************************************/
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<assert.h>
#define i64 long long
#define fr(i,a,b) for(int i=(a),end_##i=(b);i<=end_##i;i++)
#define fd(i,a,b) for(int i=(a),end_##i=(b);i>=end_##i;i--)
int read()
{
	int r=0,t=1,c=getchar();
	while(c<'0'||c>'9')
	{
		t=c=='-'?-1:1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		r=r*10+c-48;
		c=getchar();
	}
	return r*t;
}
const int N=10010;
int n,q,m;
i64 h[N];
int main()
{
	n=read(); q=read(); m=read();
	fr(i,1,n) h[i]=read();
	while(q--)
	{
		int op=read();
		if(op==1)
		{
			int l=read(),r=read(); i64 s=0;
			fr(i,l,r) s+=h[i];
			printf("%lld\n",s);
		}
		else if(op==2)
		{
			int l=read(),r=read(),d=read();
			fr(i,l,r) h[i]+=d;
		}
		else if(op==3)
		{
			int l=read(),r=read();
			fr(i,l,r-1) if(h[i+1]-h[i]>m) h[i+1]=h[i]+m;
			fd(i,r-1,l) if(h[i]-h[i+1]>m) h[i]=h[i+1]+m;
		}
	}
	return 0;
}
